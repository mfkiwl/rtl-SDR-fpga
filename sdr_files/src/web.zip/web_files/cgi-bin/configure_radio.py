#! /usr/bin/python3
import cgi, cgitb, os, mmap, struct
cgitb.enable()

GPIO_BASE = 0x41200000       # AXI-GPIO base
MAP_SIZE  = 4096
GPIO_DATA = 0x00             # CH1 DATA
GPIO_TRI  = 0x04             # CH1 TRI (1=input, 0=output)
STREAM_BIT = 0               # <- the bit you wired into the TVALID gate
STREAM_MASK = 1 << STREAM_BIT

class MM:
    def __init__(self, base):
        self.fd = os.open("/dev/mem", os.O_RDWR | os.O_SYNC)
        self.mm = mmap.mmap(self.fd, MAP_SIZE, flags=mmap.MAP_SHARED,
                            prot=mmap.PROT_READ | mmap.PROT_WRITE, offset=base)
    def close(self):
        try: self.mm.close()
        finally: os.close(self.fd)
    def rd(self, off):
        self.mm.seek(off); return struct.unpack("<I", self.mm.read(4))[0]
    def wr(self, off, val):
        self.mm.seek(off); self.mm.write(struct.pack("<I", val & 0xFFFFFFFF))

form = cgi.FieldStorage()
streaming_enabled = (form.getfirst('streaming') == 'streaming')  # checkbox present only when checked

err = None
try:
    gpio = MM(GPIO_BASE)
    try:
        # 1) make STREAM_BIT an output (preserve others)
        tri = gpio.rd(GPIO_TRI)
        tri &= ~STREAM_MASK
        gpio.wr(GPIO_TRI, tri)

        # 2) set/clear DATA bit (ACTIVE-HIGH enable; flip the sense here if your PL expects active-low)
        data = gpio.rd(GPIO_DATA)
        if streaming_enabled:
            data |= STREAM_MASK
        else:
            data &= ~STREAM_MASK
        gpio.wr(GPIO_DATA, data)

        # 3) read back
        rb_tri  = gpio.rd(GPIO_TRI)
        rb_data = gpio.rd(GPIO_DATA)
    finally:
        gpio.close()
except Exception as e:
    err = str(e)

print("Content-type:text/html\n")
print("<html><body>")
print(f"Streaming checkbox: {'ON' if streaming_enabled else 'OFF'}<br>")
if err:
    print(f"<p style='color:red'>ERROR: {err}</p>")
else:
    print(f"GPIO TRI = 0x{rb_tri:08X} (bit{STREAM_BIT} should be 0)<br>")
    print(f"GPIO DATA= 0x{rb_data:08X} (bit{STREAM_BIT} now {'1' if streaming_enabled else '0'})<br>")
print("</body></html>")
